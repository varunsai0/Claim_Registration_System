package com.cg.ics.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.mainclasses.Agent;
import com.cg.ics.mainclasses.Insured;
import com.cg.ics.mainclasses.UnderWriter;
import com.cg.ics.service.Login;
import com.cg.ics.service.implementation.LoginImpl;

public class MainUI {

	public static void main(String[] args) {

		Scanner scanner = null;
		Login login= new LoginImpl();

		boolean validateLoginFlag = false;

		String roleCode = "";
		System.out.println("\t\t\tInsurace Claim System");
		do {
			scanner = new Scanner(System.in);
			System.out.println("Enter the username:");
			String userName = scanner.nextLine();
			System.out.println("Enter the password:");
			String password = scanner.nextLine();
			try {
				validateLoginFlag = login.validateLoginDetails(userName,
						password);
			} catch (ICSException e1) {
				System.err.println("Connection Error");
			}
			if (validateLoginFlag) {
				roleCode = login.getRoleCode();
try {
				switch (roleCode) {
				case "1001":
					
				
					boolean insuredFlag=false;
					boolean insuredDoFlag=true;
						do {
							
							Insured.insured(userName);
							
							do {
							System.out.println("Do you want to EXIT.");
							System.out.println("1. Yes\t\t2. No");
							try {
								scanner = new Scanner(System.in);
								int insuredFlagExit= scanner.nextInt();
							
							switch (insuredFlagExit) {
							case 1:
								insuredFlag=true;
								break;
							case 2:
								insuredFlag=true;
								insuredDoFlag=false;
								break;

							default:
								insuredFlag=false;
								System.err.println("Enter valid choice");
								break;
							}
							
							}catch(InputMismatchException e) {
								insuredFlag=false;
								System.err.println("Enter valid choice only in digits");
							}
						} while (!insuredFlag);
						}while(!insuredDoFlag);
						break;

				
				case "1002":
					
					
					
					boolean AgentFlag=false;
					boolean agentDoFlag=true;
						do {
							
							Agent.agent(userName);
							
							do {
							System.out.println("Do you want to EXIT.");
							System.out.println("1. Yes\t\t2. No");
							try {
								scanner = new Scanner(System.in);
								int agentFlagExit= scanner.nextInt();
							
							switch (agentFlagExit) {
							case 1:
								AgentFlag=true;
								break;
							case 2:
								AgentFlag=true;
								agentDoFlag=false;
								break;

							default:
								AgentFlag=false;
								System.err.println("Enter valid choice");
								break;
							}
							
							}catch(InputMismatchException e) {
								AgentFlag=false;
								System.err.println("Enter valid choice only in digits");
							}
						} while (!AgentFlag);
						}while(!agentDoFlag);
						break;
					
					
					
				
				case "1003":
				boolean AdminFlag=false;
				boolean adminDoFlag=true;
					do {
						
						UnderWriter.underWriter(userName);
						
						do {
						System.out.println("Do you want to EXIT.");
						System.out.println("1. Yes\t\t2. No");
						try {
							scanner = new Scanner(System.in);
							int AdminFlagExit= scanner.nextInt();
						
						switch (AdminFlagExit) {
						case 1:
							   AdminFlag=true;
							break;
						case 2:
							AdminFlag=true;
							adminDoFlag=false;
							break;

						default:
							AdminFlag=false;
							System.err.println("Enter valid choice");
							break;
						}
						
						}catch(InputMismatchException e) {
							AdminFlag=false;
							System.err.println("Enter valid choice only in digits");
						}
					} while (!AdminFlag);
					}while(!adminDoFlag);
					break;
				default:
					  System.err.println("Invalid Choice. Please try again...");
					  break;
				}
			}catch (InputMismatchException e) {
				
				System.err.println("Enter only digits ");
			}
			}
		} while (!validateLoginFlag);
		scanner.close();
	}
}
