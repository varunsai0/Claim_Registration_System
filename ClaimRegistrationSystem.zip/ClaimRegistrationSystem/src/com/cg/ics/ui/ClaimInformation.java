package com.cg.ics.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.ClaimQuestions;
import com.cg.ics.model.PolicyDetails;
import com.cg.ics.service.CommomMethods;
import com.cg.ics.service.ICSService;
import com.cg.ics.service.implementation.CommonMethodsImpl;
import com.cg.ics.service.implementation.ICSServiceImpl;

public class ClaimInformation {

	public static Claim getClaimInformation() {
		ICSService service = new ICSServiceImpl();
		Claim claim = new Claim();
		boolean validateInformationFlag = false;
		boolean validatePolicyNumberFlag = false;
		Scanner scanner = new Scanner(System.in);
		Long policyNumber = 0l;
		CommomMethods commonMethod= new CommonMethodsImpl();

		do {
			try {
				scanner = new Scanner(System.in);
				System.out.println("Enter Policy No.: ");
				policyNumber = scanner.nextLong();
				try {
					validatePolicyNumberFlag = commonMethod
							.validatePolicyNumber(policyNumber);
					if (commonMethod.checkWhetherClaimed(policyNumber)) {
						scanner.close();
						return null;
					}
					claim.setPolicyNumber(policyNumber);

				} catch (ICSException e) {
					System.err
							.println("Error Establishing connection. Please try again...");
					e.getStackTrace();
				}
			} catch (InputMismatchException e) {
				System.err
						.println("Policy No. should be a 10 Digit Number Only. Please try Again...");
				validatePolicyNumberFlag = false;
			}

		} while (!validatePolicyNumberFlag);

		scanner.nextLine();

		do {

			System.out.println("Enter reason for Claim:");
			claim.setClaimReason(scanner.nextLine());

			System.out
					.println("Please provide address where Accident Happend in following fields");
			System.out.println("Enter Street name:");
			claim.setAccidentLocationStreet(scanner.nextLine());

			System.out.println("Enter City name:");
			claim.setAccidentCity(scanner.nextLine());

			System.out.println("Enter State name:");
			claim.setAccidentState(scanner.nextLine());
			boolean validateaccidentZipFlag = false;
			do {

				try {
					scanner = new Scanner(System.in);
					System.out.println("Enter Zip Code:");
					claim.setAccidentZip(scanner.nextLong());
					validateaccidentZipFlag = true;
				} catch (InputMismatchException e) {
					System.err.println("Zip should contain only INTEGER values. Please try again...");
				}

			} while (!validateaccidentZipFlag);

			validateInformationFlag = service.validateClaimInformationDetails(claim);
			if (!validateInformationFlag) {
				scanner.nextLine();
			}

		} while (!validateInformationFlag);

		boolean validateClaimTypeFlag = false;

		do {

			System.out.println("Choose Claim types:");
			System.out.println("1. EarthQuake.");
			System.out.println("2. Flood.");
			System.out.println("3. Collision.");
			System.out.println("4. Fire.");
			System.out.println("5. Hurricane.");
			try {
				scanner = new Scanner(System.in);
				int claimTypeChoice = scanner.nextInt();
				validateClaimTypeFlag = true;
				switch (claimTypeChoice) {
				case 1:
					claim.setClaimType("EarthQuake");
					break;
				case 2:
					claim.setClaimType("Flood");
					break;
				case 3:
					claim.setClaimType("Collision");
					break;
				case 4:
					claim.setClaimType("Fire");
					break;
				case 5:
					claim.setClaimType("Hurricane");
					break;
				default:
					System.err.println("Invalid Choice. Please Try again...");
					validateClaimTypeFlag = false;
					break;
				}
			} catch (InputMismatchException e) {
				System.err
						.println("Choice should contain only INTEGER values. Please try again...");
			}

		} while (!validateClaimTypeFlag);
		
		boolean validateQuestionsFlag=false;
		List<ClaimQuestions> questionsList = new ArrayList<ClaimQuestions>();
		try {
			questionsList = commonMethod.claimQuestions(policyNumber);
			for (ClaimQuestions claimQuestions : questionsList) {
				
				do {
					validateQuestionsFlag=false;
					System.out.println(claimQuestions.getClaimQuesDesc());
					System.out.println("1. " + claimQuestions.getClaimQuesAns1()+"\t2. " + claimQuestions.getClaimQuesAns2()+"\t3. " + claimQuestions.getClaimQuesAns3()+"\t4." + claimQuestions.getClaimQuesAns4());
					try {
						
						int questionChoice = scanner.nextInt();
						validateQuestionsFlag=true;
						PolicyDetails details = new PolicyDetails();
						switch (questionChoice) {
						case 1:

							details.setPolicyNumber(policyNumber);
							details.setQuestionId(claimQuestions.getClaimQuesId());
							details.setAnswer(claimQuestions.getClaimQuesAns1());
							commonMethod.insertIntoPolicyDetails(details);
							break;
						case 2:

							details.setPolicyNumber(policyNumber);
							details.setQuestionId(claimQuestions.getClaimQuesId());
							details.setAnswer(claimQuestions.getClaimQuesAns2());
							commonMethod.insertIntoPolicyDetails(details);
							break;
						case 3:

							details.setPolicyNumber(policyNumber);
							details.setQuestionId(claimQuestions.getClaimQuesId());
							details.setAnswer(claimQuestions.getClaimQuesAns3());
							commonMethod.insertIntoPolicyDetails(details);
							break;
						case 4:

							details.setPolicyNumber(policyNumber);
							details.setQuestionId(claimQuestions.getClaimQuesId());
							details.setAnswer(claimQuestions.getClaimQuesAns4());
							commonMethod.insertIntoPolicyDetails(details);
							break;
						default:
							System.err.println("Invalid Choice. Please try again...");
							validateQuestionsFlag=false;
							break;
						}
						
					} catch (InputMismatchException e) {
						System.err.println("Please Enter Only Digits(1 to 4) Only...");
					}
	
				} while (!validateQuestionsFlag);
			}
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}

		scanner.close();
		return claim;
		
	}

	
	
	
	
}
