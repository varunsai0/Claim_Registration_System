package com.cg.ics.service.implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import com.cg.ics.dao.AgentMethods;
import com.cg.ics.dao.CommonMethods;
import com.cg.ics.dao.InsuredMethods;
import com.cg.ics.dao.UnderWriterMethods;
import com.cg.ics.dao.implementation.AgentMethodsImpl;
import com.cg.ics.dao.implementation.CommonMethodsImplementation;
import com.cg.ics.dao.implementation.InsuredMethodsImpl;
import com.cg.ics.dao.implementation.UnderWriterMethodsImpl;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.ClaimQuestions;
import com.cg.ics.model.PolicyDetails;
import com.cg.ics.service.CommomMethods;

public class CommonMethodsImpl implements CommomMethods{
	
	List<String> list = null;
	CommonMethods commonMethodsDao= new CommonMethodsImplementation();
	AgentMethods agent= new AgentMethodsImpl();
	InsuredMethods insured= new InsuredMethodsImpl();
	UnderWriterMethods underWriter= new UnderWriterMethodsImpl();
	
	@Override
	public List<ClaimQuestions> claimQuestions(Long policyNumber)throws ICSException {
		return commonMethodsDao.claimQuestions(policyNumber);
	}
	
	@Override
	public int insertIntoPolicyDetails(PolicyDetails details)
			throws ICSException {
		return commonMethodsDao.insertIntoPolicyDetails(details);
	}
	
	@Override
	public boolean validatePolicyNumber(Long policyNumber) throws ICSException {
		list = new ArrayList<String>();

		boolean validatePolicyNumberFlag = false;
		if (!validatePolicyNo(policyNumber)) {
			list.add("INVALID POLICY NO. Policy Number Strictly be 10 Digits Only...");
		} else {
			validatePolicyNumberFlag = commonMethodsDao.validatePolicyNumber(policyNumber);
			if(!validatePolicyNumberFlag){
				list.add("No Policy Found with Policy No.: "+policyNumber);
			}
		}
		if (list.size() > 0) {
			System.err.println(list);
			validatePolicyNumberFlag = false;
		}
		return validatePolicyNumberFlag;
	}

	
	@Override
	public Long generateClaim(Claim claim) throws ICSException {
		return commonMethodsDao.generateClaim(claim);
	}
	
	@Override
	public List<Claim> viewClaim(String userName) throws ICSException {
		return commonMethodsDao.viewClaim(userName);
	}
	
	@Override
	public boolean checkWhetherClaimed(Long policyNumber) throws ICSException {
		boolean checkWhetherClaimedFlag=commonMethodsDao.checkWhetherClaimed(policyNumber);
		if(checkWhetherClaimedFlag){
			System.err.println("This Policy has already been claimed. Thank You!!");
		}
		return checkWhetherClaimedFlag;
	}
	
	
	
	private boolean validatePolicyNo(Long policyNumber) {
		String policyNumberRegEx = "[0-9]{10}$";
		return Pattern.matches(policyNumberRegEx, policyNumber.toString());
	}

	
	
	

}
