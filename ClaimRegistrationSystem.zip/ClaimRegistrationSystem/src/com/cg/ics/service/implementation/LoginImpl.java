package com.cg.ics.service.implementation;

import java.util.regex.Pattern;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.service.Login;

public class LoginImpl implements Login{
	com.cg.ics.dao.Login login= new com.cg.ics.dao.implementation.LoginImpl();
	
	//=================================LOGIN====================================
		@Override
		public boolean validateLoginDetails(String userName, String password) throws ICSException{
			
			String usernameRegEx = "[A-Za-z0-9]{4,15}";
			String passwordRegEx = "[A-Za-z0-9]{4,15}";
			boolean loginFlag=false;
			if(Pattern.matches(usernameRegEx, userName) && Pattern.matches(passwordRegEx, password)){
				loginFlag=login.userLogin(userName,password);
				if(!loginFlag){
					System.err.println("INVALID USERNAME OR PASSWORD. TRY AGAIN");
				}
			}else{
				System.err.println("Username and Password should be of minimum 3 and maximum 15 Characters... Please Try Again...");
			}
			return loginFlag;
		}

		@Override
		public String getRoleCode() {
			return login.getRoleCode();
		}


}
