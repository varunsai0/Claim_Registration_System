package com.cg.ics.service.implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.ics.dao.AgentMethods;
import com.cg.ics.dao.InsuredMethods;
import com.cg.ics.dao.UnderWriterMethods;
import com.cg.ics.dao.implementation.AgentMethodsImpl;
import com.cg.ics.dao.implementation.InsuredMethodsImpl;
import com.cg.ics.dao.implementation.UnderWriterMethodsImpl;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.Policy;
import com.cg.ics.model.PolicyDetails;
import com.cg.ics.model.UserRole;
import com.cg.ics.service.ICSService;

public class ICSServiceImpl implements ICSService {

	
	AgentMethods agent= new AgentMethodsImpl();
	InsuredMethods insured= new InsuredMethodsImpl();
	UnderWriterMethods underWriter= new UnderWriterMethodsImpl();
	List<String> list = null;

	@Override
	public boolean validateClaimInformationDetails(Claim claim) {
		boolean validateClaimInformationFlag=false;
		list= new ArrayList<String>();
		
		if(!validateClaimReason(claim.getClaimReason())){
			list.add("Reason: Reason Should not be less than 5 character and not Greater than 30 characters.");
		}
		if(!validateAccidentStreet(claim.getAccidentLocationStreet())){
			list.add("Street: Street should not be less than 3 characters and should not exceed 40 characters.");
		}
		if(!validateAccidentCity(claim.getAccidentCity())){
			list.add("City: City name should not be less than 2 characters as well as should not exceed 15 characters.");
		}
		if(!validateAccidentState(claim.getAccidentState())){
			list.add("State: State name should not be less than 2 characters as well as should not exceed 15 characters.");
		}
		if(!validateAccidentZip(claim.getAccidentZip())){
			list.add("Zip: Zip code should strictly be 5 Digits only.");
		}
		if(list.size()>0){
			for (String string : list) {
				System.err.println(string);
			}
			validateClaimInformationFlag=false;
		}else {
			validateClaimInformationFlag=true;
		}
	
		return validateClaimInformationFlag;
	}

	private boolean validateAccidentZip(Long accidentZip) {
		String accidentZipRegEx = "[0-9]{5}$";
		return Pattern.matches(accidentZipRegEx, accidentZip.toString());
	}

	private boolean validateAccidentState(String accidentState) {
		String accidentStateRegEx = "[A-Za-z0-9\\s,]{2,15}$";
		return Pattern.matches(accidentStateRegEx, accidentState);
	}

	private boolean validateAccidentCity(String accidentCity) {
		String accidentCityRegEx = "[A-Za-z0-9\\s,]{2,15}$";
		return Pattern.matches(accidentCityRegEx, accidentCity);
	}

	private boolean validateAccidentStreet(String accidentStreet) {
		String accidentStreetRegEx = "[A-Za-z0-9\\s,]{3,40}$";
		return Pattern.matches(accidentStreetRegEx, accidentStreet);
	}

	private boolean validateClaimReason(String claimReason) {
		String accidentClaimReasonRegEx = "[A-Za-z0-9\\s,]{5,30}$";
		return Pattern.matches(accidentClaimReasonRegEx, claimReason);
	}
	
		@Override
	public List<Claim> viewClaimDetailsBasedOnPolicyNumber(Long policyNumberToviewClaimDetails) throws ICSException {
		return agent.viewClaimDetailsBasedOnPolicyNumber(policyNumberToviewClaimDetails);
	}
	
	
	//================================INSURED===============================
	
	@Override
	public List<Policy> getPolicyList(String userName) throws ICSException {
		return insured.getPolicyList(userName);
	}
	
	//===============================UNDERWRITER=============================
	
	@Override
	public boolean checkUserNameInData(String username1) throws ICSException {
		return underWriter.checkUserNameInData(username1);
	}
	
	@Override
	public int insertNewUser(UserRole role) throws ICSException {
		return underWriter.insertNewUser(role);
	}
	
	@Override
	public List<Claim> viewClaimDetails() throws ICSException{
		return underWriter.viewClaimDetails();
	}
	
	@Override
	public List<Claim> getAllClaims() throws ICSException {
		return underWriter.getAllClaims();
	}
	
	@Override
	public List<PolicyDetails> reportGeneration(Long policyNumber) throws ICSException {
		return underWriter.reportGeneration(policyNumber);
	}

	@Override
	public List<Policy> getAllPolicyList() throws ICSException {
		return underWriter.getAllPolicyList();
	}

}
