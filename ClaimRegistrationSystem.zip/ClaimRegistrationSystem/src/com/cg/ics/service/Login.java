package com.cg.ics.service;

import com.cg.ics.exceptions.ICSException;

public interface Login {
	
	boolean validateLoginDetails(String userName, String password) throws ICSException;

	String getRoleCode();

}
