package com.cg.ics.exceptions;

public class ICSException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ICSException(String message) {
	
		super(message);
	}

}
