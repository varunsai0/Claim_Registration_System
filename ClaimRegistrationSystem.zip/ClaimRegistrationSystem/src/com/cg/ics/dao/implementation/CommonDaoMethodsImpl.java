package com.cg.ics.dao.implementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ics.dao.CommonDaoMethods;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.ClaimQuestions;
import com.cg.ics.model.PolicyDetails;
import com.cg.ics.queries.QueryMapper;
import com.cg.ics.utility.JdbcUtility;

public class CommonDaoMethodsImpl implements CommonDaoMethods{
	
	Connection connection= null;
	ResultSet resultSet=null;
	PreparedStatement prepareStatement=null;
	
	
	public List<ClaimQuestions> claimQuestions(Long policyNumber)
			throws ICSException {
		connection = JdbcUtility.getConnection();
		List<ClaimQuestions> list = new ArrayList<ClaimQuestions>();
		try {
			prepareStatement = connection.prepareStatement(QueryMapper.claimQuestions);
			prepareStatement.setLong(1, policyNumber);
			resultSet = prepareStatement.executeQuery();
			while (resultSet.next()) {
				String quesId = resultSet.getString(1);
				int quesSeq = resultSet.getInt(2);
				String busSegId = resultSet.getString(3);
				String quesDesc = resultSet.getString(4);
				String ans1 = resultSet.getString(5);
				Long ans1Weight = resultSet.getLong(6);
				String ans2 = resultSet.getString(7);
				Long ans2Weight = resultSet.getLong(8);
				String ans3 = resultSet.getString(9);
				Long ans3Weight = resultSet.getLong(10);
				String ans4 = resultSet.getString(11);
				Long ans4Weight = resultSet.getLong(12);

				ClaimQuestions questions = new ClaimQuestions();
				questions.setClaimQuesId(quesId);
				questions.setClaimQuesSeq(quesSeq);
				questions.setBusSegId(busSegId);
				questions.setClaimQuesDesc(quesDesc);
				questions.setClaimQuesAns1(ans1);
				questions.setClaimQuesAns1Weightage(ans1Weight);
				questions.setClaimQuesAns2(ans2);
				questions.setClaimQuesAns2Weightage(ans2Weight);
				questions.setClaimQuesAns3(ans3);
				questions.setClaimQuesAns3Weightage(ans3Weight);
				questions.setClaimQuesAns4(ans4);
				questions.setClaimQuesAns4Weightage(ans4Weight);
				list.add(questions);
			}
		}catch (SQLException e) {
			throw new ICSException("claimQuestions: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new ICSException("claimQuestions: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
			} catch (SQLException e) {
				throw new ICSException("claimQuestions: Prepared Statement not closed.");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new ICSException("claimQuestions: Connection not closed.");
			}
		}
		return list;
	}
	
	
	
	
	
	
	@Override
	public int insertIntoPolicyDetails(PolicyDetails details)
			throws ICSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			prepareStatement = connection.prepareStatement(QueryMapper.insertIntoPolicyDetails);
			prepareStatement.setLong(1, details.getPolicyNumber());
			prepareStatement.setString(2, details.getQuestionId());
			prepareStatement.setString(3, details.getAnswer());
			result = prepareStatement.executeUpdate();
		}catch (SQLException e) {
			throw new ICSException("insertIntoPolicyDetails: Prepared Statement not created.");
		}finally{
			try {
				prepareStatement.close();
			} catch (SQLException e) {
				throw new ICSException("insertIntoPolicyDetails: Prepared Statement not closed.");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new ICSException("insertIntoPolicyDetails: Connection not closed.");
			}
		}
		return result;
	}
	
	
	@Override
	public boolean validatePolicyNumber(Long policyNumber) throws ICSException {
		boolean validatePolicyNumberFlag = false;
		connection = JdbcUtility.getConnection();
		try {
			prepareStatement = connection
					.prepareStatement(QueryMapper.validatePolicyNumberQuery);
		
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				Long policyDataNumber=resultSet.getLong(1);
				if(policyDataNumber.equals(policyNumber)) {
				
					validatePolicyNumberFlag=true;
				}
			}
			
			/*if(!validatePolicyNumberFlag) {
				System.err.println("There is no such policy number");
			}*/
		}catch (SQLException e) {
			throw new ICSException("validatePolicyNumber: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new ICSException("validatePolicyNumber: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
			} catch (SQLException e) {
				throw new ICSException("validatePolicyNumber: Prepared Statement not closed.");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new ICSException("validatePolicyNumber: Connection not closed.");
			}
		}
		return validatePolicyNumberFlag;
	}
	
	
	
	@Override
	public boolean checkWhetherClaimed(Long policyNumber) throws ICSException {
		boolean checkWhetherClaimedFlag = false;
		connection = JdbcUtility.getConnection();
		try {
			prepareStatement = connection
					.prepareStatement(QueryMapper.getClaimNumberOrCheckWhetherClaimedQuery);
			prepareStatement.setLong(1, policyNumber);
			resultSet = prepareStatement.executeQuery();
			if (resultSet.next()) {
				checkWhetherClaimedFlag = true;
			} else {
				checkWhetherClaimedFlag = false;
			}
		}catch (SQLException e) {
			throw new ICSException("checkWhetherClaimed: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new ICSException("checkWhetherClaimed: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
			} catch (SQLException e) {
				throw new ICSException("checkWhetherClaimed: Prepared Statement not closed.");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new ICSException("checkWhetherClaimed: Connection not closed.");
			}
		}
		return checkWhetherClaimedFlag;
	}
	
	@Override
	public Long generateClaim(Claim claim) throws ICSException {
		Long clainNumber = null;
		connection = JdbcUtility.getConnection();

		try {
			prepareStatement = connection
					.prepareStatement(QueryMapper.addGenerateClaimQuery);
			prepareStatement.setString(1, claim.getClaimReason());
			prepareStatement.setString(2, claim.getAccidentLocationStreet());
			prepareStatement.setString(3, claim.getAccidentCity());
			prepareStatement.setString(4, claim.getAccidentState());
			prepareStatement.setLong(5, claim.getAccidentZip());
			prepareStatement.setString(6, claim.getClaimType());
			prepareStatement.setLong(7, claim.getPolicyNumber());
			prepareStatement.executeUpdate();

			prepareStatement = connection
					.prepareStatement(QueryMapper.getClaimNumberOrCheckWhetherClaimedQuery);
			prepareStatement.setLong(1, claim.getPolicyNumber());
			resultSet = prepareStatement.executeQuery();
			if (resultSet.next()) {
				clainNumber = resultSet.getLong(1);
			}
		}catch (SQLException e) {
			throw new ICSException("generateClaim: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new ICSException("generateClaim: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
			} catch (SQLException e) {
				throw new ICSException("generateClaim: Prepared Statement not closed.");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new ICSException("generateClaim: Connection not closed.");
			}
		}
		return clainNumber;
	}
	
	
	public List<Claim> viewClaim(String userName) throws ICSException {
		connection = JdbcUtility.getConnection();
		List<Claim> list = new ArrayList<Claim>();
		try {
			prepareStatement = connection.prepareStatement(QueryMapper.viewClaim);
			prepareStatement.setString(1, userName);
			System.err.println(userName);
			resultSet = prepareStatement.executeQuery();

			while (resultSet.next()) {
				Long claimNumber = resultSet.getLong(1);
				String claimReason = resultSet.getString(2);
				String street = resultSet.getString(3);
				String city = resultSet.getString(4);
				String state = resultSet.getString(5);
				Long zip = resultSet.getLong(6);
				String claimType = resultSet.getString(7);
				Long policyNumber = resultSet.getLong(8);

				Claim claim = new Claim();

				claim.setClaimNumber(claimNumber);
				claim.setClaimReason(claimReason);
				claim.setAccidentLocationStreet(street);
				claim.setAccidentCity(city);
				claim.setAccidentState(state);
				claim.setAccidentZip(zip);
				claim.setClaimType(claimType);
				claim.setPolicyNumber(policyNumber);
				list.add(claim);
				}
		}catch (SQLException e) {
			throw new ICSException("viewClaim: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new ICSException("viewClaim: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
			} catch (SQLException e) {
				throw new ICSException("viewClaim: Prepared Statement not closed.");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new ICSException("viewClaim: Connection not closed.");
			}
		}
		return list;
	}
	
	
	
	
	
	
	

}
