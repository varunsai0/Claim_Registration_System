package com.cg.ics.dao.implementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.ics.dao.Login;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.queries.QueryMapper;
import com.cg.ics.utility.JdbcUtility;

public class LoginImpl implements Login{
	
	static Logger logger = Logger.getLogger(LoginImpl.class);
	
	
	Connection connection= null;
	PreparedStatement prepareStatement=null;
	ResultSet resultSet=null;
	String roleCode;
	
	@Override
	public boolean userLogin(String userName, String password)throws ICSException {
		connection = JdbcUtility.getConnection();

		boolean loginFlag = false;
		try {
			prepareStatement = connection.prepareStatement(QueryMapper.getLoginDetails);
			logger.info("prepare statement is called");
			resultSet = prepareStatement.executeQuery();
			logger.info("execute statement called");
			while (resultSet.next()) {
				String dataUserName = resultSet.getString("username");
				String dataPassword = resultSet.getString("password");
				if (userName.equals(dataUserName) && password.equals(dataPassword)) {
					loginFlag = true;
					roleCode = resultSet.getString("role_code");	
				}
			}
		} catch (SQLException e) {
			logger.error("Error :" +e.getMessage());
			throw new ICSException("userLogin: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
				logger.info("result set is closed");
			} catch (SQLException e) {
				logger.error("Error :" +e.getMessage());
				throw new ICSException("userLogin: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
				logger.info("prepare statement  is closed");
			} catch (SQLException e) {
				logger.error("Error :" +e.getMessage());
				throw new ICSException("userLogin: Prepared Statement not closed.");
			}
			try {
				connection.close();
				logger.info("connection is closed");
			} catch (SQLException e) {
				logger.error("Error :" +e.getMessage());
				throw new ICSException("userLogin: Connection not closed.");
			}
		}
		return loginFlag;
	}

	@Override
	public String getRoleCode() {
		logger.info("role code is returned");
		return roleCode;
		
	}


}
