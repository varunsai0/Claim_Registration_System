package com.cg.ics.dao.implementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ics.dao.AgentMethods;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.queries.QueryMapper;
import com.cg.ics.utility.JdbcUtility;

public class AgentMethodsImpl implements AgentMethods{
	
	static Logger logger = Logger.getLogger(AgentMethodsImpl.class);
	
	
	Connection connection=null;
	PreparedStatement prepareStatement=null;
	ResultSet resultSet=null;
	
	
	@Override
	public List<Claim> viewClaimDetailsBasedOnPolicyNumber(
			Long policyNumberToviewClaimDetails) throws ICSException {
		List<Claim> list = new ArrayList<>();

		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection
					.prepareStatement(QueryMapper.viewClaimDetailsBasedOnPolicyNumber);
			logger.info("prepare statement called");

			prepareStatement.setLong(1, policyNumberToviewClaimDetails);

			resultSet = prepareStatement.executeQuery();
			logger.info("execute statement called");


			while (resultSet.next()) {

				Long policyNumberData = resultSet.getLong("policy_Number");

				if (policyNumberToviewClaimDetails.equals(policyNumberData)) {

					Long claimNumber = resultSet.getLong("claim_Number");
					String claimType = resultSet.getString("claim_Type");
					Claim claim = new Claim();
					
					logger.debug("claim object is created");
					
					claim.setPolicyNumber(policyNumberData);
					claim.setClaimNumber(claimNumber);
					claim.setClaimType(claimType);
					list.add(claim);
					logger.debug("claim details added into the list");

				}
			}
		}catch (SQLException e) {
			logger.error("Error:" +e.getMessage());
			throw new ICSException("viewClaimDetails: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
				logger.info("resultset is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("viewClaimDetails: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
				logger.info("prepare statement is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("viewClaimDetails: Prepared Statement not closed.");
			}
			try {
				connection.close();
				logger.info("execute statement called");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("viewClaimDetails: Connection not closed.");
			}
		}
		return list;
	}
	

}
