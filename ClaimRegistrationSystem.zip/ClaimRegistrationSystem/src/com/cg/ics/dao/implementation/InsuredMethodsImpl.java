package com.cg.ics.dao.implementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ics.dao.InsuredMethods;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.BusinessSegment;
import com.cg.ics.model.Policy;
import com.cg.ics.queries.QueryMapper;
import com.cg.ics.utility.JdbcUtility;

public class InsuredMethodsImpl implements InsuredMethods {

	static Logger logger = Logger.getLogger(InsuredMethodsImpl.class);

	Connection connection = null;
	PreparedStatement prepareStatement = null;
	ResultSet resultSet = null;

	@Override
	public List<Policy> getPolicyList(String userName) throws ICSException {
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		List<Policy> list = new ArrayList<Policy>();
		try {
			prepareStatement = connection
					.prepareStatement(QueryMapper.getPolicyList);
			logger.info("prepare statement is called");
			prepareStatement.setString(1, userName);
			resultSet = prepareStatement.executeQuery();
			logger.info("execute statement is called");
			while (resultSet.next()) {
				long policyNumber = resultSet.getLong(1);
				Double policyPremium = resultSet.getDouble(2);
				String busSegName = resultSet.getString(4);

				BusinessSegment segment = new BusinessSegment();
				logger.debug("business segment object is created");
				segment.setBusSegName(busSegName);
				Policy policy = new Policy();
				logger.debug("policy object is created");
				policy.setPolicyNumber(policyNumber);
				policy.setPolicyPremium(policyPremium);
				policy.setBusinessSegment(segment);

				list.add(policy);
				logger.info(" policy details added into the list");
			}
		} catch (SQLException e) {
			logger.error("Error :" + e.getMessage());
			throw new ICSException(
					"getPolicyList: Prepared Statement not created.");
		} finally {
			try {
				resultSet.close();
				logger.info("result set is closed");
			} catch (SQLException e) {
				logger.error("Error :" + e.getMessage());
				throw new ICSException("getPolicyList: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
				logger.info("prepare statement is closed");
			} catch (SQLException e) {
				logger.error("Error :" + e.getMessage());
				throw new ICSException(
						"getPolicyList: Prepared Statement not closed.");
			}
			try {
				connection.close();
				logger.info("connection is closed");
			} catch (SQLException e) {
				logger.error("Error :" + e.getMessage());
				throw new ICSException("getPolicyList: Connection not closed.");
			}
		}
		return list;
	}

}
