package com.cg.ics.dao.implementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ics.dao.UnderWriterMethods;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.BusinessSegment;
import com.cg.ics.model.Claim;
import com.cg.ics.model.Policy;
import com.cg.ics.model.PolicyDetails;
import com.cg.ics.model.UserRole;
import com.cg.ics.queries.QueryMapper;
import com.cg.ics.utility.JdbcUtility;

public class UnderWriterMethodsImpl implements UnderWriterMethods{

	static Logger logger = Logger.getLogger(UnderWriterMethodsImpl.class);
	
	Connection connection= null;
	ResultSet resultSet=null;
	PreparedStatement prepareStatement=null;
	
	
	
	@Override
	public List<Policy> getAllPolicyList() throws ICSException {
		
		
		connection = JdbcUtility.getConnection();
		List<Policy> list = new ArrayList<Policy>();
		try {
			prepareStatement = connection
					.prepareStatement(QueryMapper.getAllPolicyListQuery);
			logger.info("prepare statement called");
			resultSet = prepareStatement.executeQuery();
			logger.info("execute statement is called");
			while (resultSet.next()) {
				long policyNumber = resultSet.getLong(1);
				Double policyPremium = resultSet.getDouble(2);
				String busSegName = resultSet.getString(4);

				BusinessSegment segment = new BusinessSegment();
				logger.debug("business segment object is created");
				segment.setBusSegName(busSegName);
				Policy policy = new Policy();
				logger.debug("Policy object is created");
				policy.setPolicyNumber(policyNumber);
				policy.setPolicyPremium(policyPremium);
				policy.setBusinessSegment(segment);

				list.add(policy);
				logger.debug("policy objects are added into  the list");
				
			}
		}catch (SQLException e) {
			throw new ICSException("getPolicyList: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
				logger.info("result set is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("getPolicyList: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
				logger.info("prepare statement is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("getPolicyList: Prepared Statement not closed.");
			}
			try {
				connection.close();
				logger.info("connection is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("getPolicyList: Connection not closed.");
			}
		}
		return list;
	}
	
	
	@Override
	public boolean checkUserNameInData(String username1) throws ICSException {

		connection = JdbcUtility.getConnection();
		boolean checkUserNameInDataFlag = false;

		try {
			prepareStatement = connection.prepareStatement(QueryMapper.getLoginDetails);
			logger.info("prepare statement called");
			resultSet = prepareStatement.executeQuery();
			logger.info("execute statement is called");
			while (resultSet.next()) {
				String usernameData = resultSet.getString("username");
				if (usernameData.equals(username1)) {
					checkUserNameInDataFlag = true;
				}
			}
		} catch (SQLException e) {
			logger.error("Error:" +e.getMessage());
			throw new ICSException("checkUserNameInData: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
				logger.info("result set is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("checkUserNameInData: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
				logger.info("prpeare statement is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("checkUserNameInData: Prepared Statement not closed.");
			}
			try {
				connection.close();
				logger.info("connection is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("checkUserNameInData: Connection not closed.");
			}
		}
		return checkUserNameInDataFlag;
	}
	
	
	@Override
	public int insertNewUser(UserRole role) throws ICSException {

		int result = 0;
		connection = JdbcUtility.getConnection();
		try {
			prepareStatement = connection.prepareStatement(QueryMapper.insertIntoUsers);
			logger.info("prepare statement called");

			prepareStatement.setString(1, role.getUserName());
			prepareStatement.setString(2, role.getPassword());
			prepareStatement.setString(3, role.getRoleCode());
			result = prepareStatement.executeUpdate();
			logger.info("execute statement is called");


		} catch (SQLException e) {
			
			throw new ICSException("insertNewUser: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
				logger.info("result set is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("insertNewUser: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
				logger.info("prepare statement is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("insertNewUser: Prepared Statement not closed.");
			}
			try {
				connection.close();
				logger.info("connection is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("insertNewUser: Connection not closed.");
			}
		}

		return result;
	}
	
	@Override
	public List<Claim> viewClaimDetails() throws ICSException {
		List<Claim> list = new ArrayList<>();
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection
					.prepareStatement(QueryMapper.viewClaimDetails);
			logger.info("prepare statement called");

			resultSet = prepareStatement.executeQuery();
			logger.info("execute statement is called");

			while (resultSet.next()) {
				Long policyNumber = resultSet.getLong("policy_Number");
				Long claimNumber = resultSet.getLong("claim_Number");
				String claimType = resultSet.getString("claim_Type");
				Claim claim = new Claim();
				logger.debug("Claim object is created");
				claim.setPolicyNumber(policyNumber);
				claim.setClaimNumber(claimNumber);
				claim.setClaimType(claimType);
				list.add(claim);
				logger.debug("claim details are added into the list");
			}

		}catch (SQLException e) {
			logger.error("Error:" +e.getMessage());
			throw new ICSException("viewClaimDetails: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
				logger.info("result set is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("viewClaimDetails: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
				logger.info("prepare statement is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("viewClaimDetails: Prepared Statement not closed.");
			}
			try {
				connection.close();
				logger.info("connection is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("viewClaimDetails: Connection not closed.");
			}
		}
		return list;
	}
	
	@Override
	public List<Claim> getAllClaims() throws ICSException {

		List<Claim> list = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		try {
			prepareStatement = connection.prepareStatement(QueryMapper.getAllClaims);
			logger.info("prepare statement called");
			resultSet = prepareStatement.executeQuery();
			logger.info("execute statement is  called");

			while (resultSet.next()) {
				Long claimNumber = resultSet.getLong("claim_number");
				String claimReason = resultSet.getString("claim_reason");
				String accidentStreet = resultSet.getString("accident_street");
				String accidentCity = resultSet.getString("accident_city");
				String accidentState = resultSet.getString("accident_state");
				Long accidentZip = resultSet.getLong("accident_zip");
				String claimType = resultSet.getString("claim_type");
				Long policyNumber = resultSet.getLong("policy_number");
				Claim claim = new Claim();
				logger.debug("Claim object is created");
				claim.setAccidentCity(accidentCity);
				claim.setAccidentLocationStreet(accidentStreet);
				claim.setAccidentState(accidentState);
				claim.setAccidentZip(accidentZip);
				claim.setClaimNumber(claimNumber);
				claim.setClaimReason(claimReason);
				claim.setPolicyNumber(policyNumber);
				claim.setClaimType(claimType);
				list.add(claim);
				logger.debug("claim details are added into the list");
			}
		}catch (SQLException e) {
			logger.error("Error:" +e.getMessage());
			throw new ICSException("getAllClaims: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
				logger.info("result set is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("getAllClaims: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
				logger.info("prepare statement is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("getAllClaims: Prepared Statement not closed.");
			}
			try {
				connection.close();
				logger.info("connection is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("getAllClaims: Connection not closed.");
			}
		}

		return list;
	}
	
	@Override
	public List<PolicyDetails> reportGeneration(Long policyNumber)
			throws ICSException {

		connection = JdbcUtility.getConnection();
		List<PolicyDetails> list = new ArrayList<>();
		try {
			prepareStatement = connection
					.prepareStatement(QueryMapper.getDetailedView);
			logger.info("prepare statement called");
			prepareStatement.setLong(1, policyNumber);
			resultSet = prepareStatement.executeQuery();
			logger.info("execute statement is  called");
			while (resultSet.next()) {
				Long claimNumber = resultSet.getLong("claim_number");
				String claimReason = resultSet.getString("claim_reason");
				String accidentStreet = resultSet.getString("accident_street");
				String accidentCity = resultSet.getString("accident_city");
				String accidentState = resultSet.getString("accident_state");
				Long accidentZip = resultSet.getLong("accident_zip");
				String claimType = resultSet.getString("claim_type");
				String claimQuesDesc = resultSet.getString("claim_ques_desc");
				String questionId = resultSet.getString("question_id");
				String answer = resultSet.getString("answer");
				
				PolicyDetails policyDetails = new PolicyDetails();
				logger.debug("Policy details object is creted");
				policyDetails.setAccidentCity(accidentCity);
				policyDetails.setAccidentLocationStreet(accidentStreet);
				policyDetails.setAccidentState(accidentState);
				policyDetails.setAccidentZip(accidentZip);
				policyDetails.setAnswer(answer);
				policyDetails.setClaimNumber(claimNumber);
				policyDetails.setClaimReason(claimReason);
				policyDetails.setClaimType(claimType);
				policyDetails.setQuestionId(questionId);
				policyDetails.setClaimQuesDesc(claimQuesDesc);
				list.add(policyDetails);
				logger.debug("details added into policy details");

			}
		} catch (SQLException e) {
			logger.error("Error:" +e.getMessage());
			throw new ICSException("reportGeneration: Prepared Statement not created.");
		}finally{
			try {
				resultSet.close();
				logger.info("result set is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("reportGeneration: ResultSet not closed.");
			}
			try {
				prepareStatement.close();
				logger.info("prepare statement is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("reportGeneration: Prepared Statement not closed.");
			}
			try {
				connection.close();
				logger.info("connection is closed");
			} catch (SQLException e) {
				logger.error("Error:" +e.getMessage());
				throw new ICSException("reportGeneration: Connection not closed.");
			}
		}
		return list;
	}
	
	
	
	
	

}
