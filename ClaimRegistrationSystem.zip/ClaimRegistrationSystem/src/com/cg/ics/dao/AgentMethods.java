package com.cg.ics.dao;

import java.util.List;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;

public interface AgentMethods {
	
	List<Claim> viewClaimDetailsBasedOnPolicyNumber(Long policyNumberToviewClaimDetails) throws ICSException;
}
