package com.cg.ics.dao;

import com.cg.ics.exceptions.ICSException;

public interface Login {
	
	boolean userLogin(String userName, String password) throws ICSException;

	String getRoleCode();

}
