package com.cg.ics.dao;

import java.util.List;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.ClaimQuestions;
import com.cg.ics.model.PolicyDetails;

public interface CommonDaoMethods {
	
	List<ClaimQuestions> claimQuestions(Long policyNumber) throws ICSException;
	
	int insertIntoPolicyDetails(PolicyDetails details) throws ICSException;
	
	boolean validatePolicyNumber(Long policyNumber) throws ICSException;
	
	boolean checkWhetherClaimed(Long policyNumber) throws ICSException;
	
	Long generateClaim(Claim claim) throws ICSException;
	
	List<Claim> viewClaim(String userName) throws ICSException;
	
	

}
