package com.cg.ics.dao;

import java.util.List;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.Policy;
import com.cg.ics.model.PolicyDetails;
import com.cg.ics.model.UserRole;

public interface UnderWriterMethods {

	List<Policy> getAllPolicyList() throws ICSException ;
	
	boolean checkUserNameInData(String username1) throws ICSException;
	
	int insertNewUser(UserRole role) throws ICSException;
	
	List<Claim> viewClaimDetails() throws ICSException;
	
	List<Claim> getAllClaims() throws ICSException;
	
	List<PolicyDetails> reportGeneration(Long policyNumber) throws ICSException;

}
