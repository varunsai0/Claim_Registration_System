package com.cg.ics.dao;

import java.util.List;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Policy;





public interface InsuredMethods {
	
	List<Policy> getPolicyList(String userName) throws ICSException;

}
