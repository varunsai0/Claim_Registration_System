package com.cg.ics.mainclasses;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.Policy;
import com.cg.ics.model.PolicyDetails;
import com.cg.ics.model.UserRole;
import com.cg.ics.service.CommomMethods;
import com.cg.ics.service.ICSService;
import com.cg.ics.service.implementation.CommonMethodsImpl;
import com.cg.ics.service.implementation.ICSServiceImpl;
import com.cg.ics.ui.ClaimInformation;

public class UnderWriter {
	public static boolean validateUserName(String userName) {
		String userRegEx = "[A-Z]{1}[A-Za-z0-9]{3,15}";

		return Pattern.matches(userRegEx, userName);
	}

	public static boolean validatePassword(String password) {
		String passwordRegEx = "[A-Za-z]{1}[A-Za-z0-9]{4,15}";

		return Pattern.matches(passwordRegEx, password);
	}

	public static void underWriter(String userName) {
		
		
		@SuppressWarnings("resource")
		Scanner scanner= new Scanner(System.in);
		ICSService service= new ICSServiceImpl();
		CommomMethods commonMethods= new CommonMethodsImpl();
		System.out.println("-------------------------ADMIN PORTAL----------------------");
		System.out.println("\t\t\tWelcome "+userName);
		System.out.println("1. New profile Creation\t\t2. Claim creation");
		System.out.println("3. View Claim\t\t\t4. Report Generation");
		int choice = scanner.nextInt();
		switch (choice) {

		case 1:
			System.out.println("\t\t--New Profile Creation--");
			scanner.nextLine();
			boolean userFlag = false;
			do {
				scanner = new Scanner(System.in);
				System.out
						.println("Enter the new username to create");
				String username1 = scanner.nextLine();
				boolean validateUserName = validateUserName(username1);
				if(validateUserName) {
				boolean checkFlag;
				try {
					checkFlag = service.checkUserNameInData(username1);
					
					if (!checkFlag) {

					userFlag = true;
				
					System.out.println("Enter the new password to create");
					String password1 = scanner.nextLine();
					boolean validatePasswordFlag = validatePassword(password1);
					if(validatePasswordFlag) {
					boolean roleCodeFlag = false;
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter role code:");
						String roleCode1 = scanner.nextLine();
						if (roleCode1.equals("1001")
								|| roleCode1.equals("1002")
								|| roleCode1.equals("1003")) {

							roleCodeFlag = true;
							UserRole role = new UserRole();
							role.setUserName(username1);
							role.setPassword(password1);
							role.setRoleCode(roleCode1);
							int result = service.insertNewUser(role);
							if(result==1){
							System.out.println("Profile Created:\t UserName: "+username1+"\tPassword: "+password1);
							}
						} else {
							System.err
									.println("You should enter the rolecode either as 1001 or 1002 or 1003");
							roleCodeFlag = false;
						}
					} while (!roleCodeFlag);
					
					}else
					{
						System.err.println("Your password should be of minimum 5 characters and maximum of 15 characters and should start with only character");
					}
				} else {
					System.err
							.println("Already user present in the database");
					userFlag = false;
				}
				} catch (ICSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}else {
					System.err.println("Your username should be of minimum four characters and maximum of 15 characters and should start with only capital letter");
				}
				
			} while (!userFlag);
			break;
		case 2:
			
			
			List<Policy> list = new ArrayList<Policy>();
			System.out.println("--------------------------------------------------------------------------");
			System.out.println("All Policies are mentioned below:");
			
			try {
				list = service.getAllPolicyList();
			} catch (ICSException e1) {
				System.out.println("Connection Error");
			}
			if (list.size() > 0) {
				System.out.println("Policy Number " + "\t|\t Policy Premium " + "   \t|\t  Bussiness Segment \t|");
				for (Policy policy : list) {
					System.out.println(policy.getPolicyNumber() + " \t\t " + policy.getPolicyPremium() + "\t\t\t|\t  " + policy.getBusinessSegment().getBusSegName()+"\t|");
					System.out.println("-----------------------------------------------------------------------------");
				}
			}
			
			
			
			Claim claim=null;
			Scanner scanner2 = new Scanner(System.in);
			claim = ClaimInformation.getClaimInformation();
			if (claim == null) {
				scanner2.close();
				return;
			}

		
			try {
				Long claimNumber = commonMethods.generateClaim(claim);
				System.out.println("You request for claim has been successfully generated");
				System.out.println("Your Claim Id: " + claimNumber);
				System.out.println("Please Store your claimID for viewing status of claim. Thank Yoo!!");
			} catch (ICSException e) {
				System.err.println("Cannot create Claim... Try again after some time...");
			}

			break;
		case 3:

			System.out.println("**********View Details Options**********");
			System.out.println("1.View All claim details");
			System.out.println("2.View claim details based on policy number");
			System.out.println("choose the ViewDetails option");
			int ViewDetailsChoice = scanner.nextInt();
			switch (ViewDetailsChoice) {
			case 1:

				List<Claim> list1 = new ArrayList<>();
				try {
					list1 = service.viewClaimDetails();
					System.out.println("policyNumber" + "          "+ " claimNumber" + "          "+ "claimType");
					for (Claim claim2 : list1) {
						System.out.println(claim2.getPolicyNumber()
								+ "     " + claim2.getClaimNumber()
								+ "      " + claim2.getClaimType());
					}
				} catch (ICSException e) {
					System.err.println("Connection Error");
				}

				break;
			case 2:

				List<Claim> list2 = new ArrayList<>();
				System.out
						.println("Enter the policy number to search");
				Long PolicyNumberToviewClaimDetails = scanner
						.nextLong();
				try {
					list2 = service.viewClaimDetailsBasedOnPolicyNumber(PolicyNumberToviewClaimDetails);
					if (!(list2.isEmpty())) {
						System.out.println("policyNumber" + " "+ " claimNumber" + " " + "claimType");
						for (Claim claim2 : list2) {
							System.out.println(claim2.getPolicyNumber()+ " " + claim2.getClaimNumber()+ " " + claim2.getClaimType());
						}
					} else {
						System.out.println("There is no such policy Number");
					}
				} catch (ICSException e) {
					System.err.println("Connection Error");
				}
				break;

			default:
				break;
			}

			break;
		case 4:
			List<Claim> list1 = new ArrayList<>();
			try {
				list1 = service.getAllClaims();
				System.out.println("claim number" + "   "
						+ "claim reason" + "    " + "accidentStreet"
						+ "    " + "accidentCity" + "   "
						+ "accidentState" + "   " + "accidentZip"
						+ "   " + "claimType" + "   " + "policyNumber");

				for (Claim claim1 : list1) {
					// System.out.println(claim.toString());

					System.out.println(claim1.getClaimNumber() + "   "
							+ claim1.getClaimReason() + "   "
							+ claim1.getAccidentLocationStreet()
							+ "   " + claim1.getAccidentCity() + "   "
							+ claim1.getAccidentState() + "   "
							+ claim1.getAccidentZip() + "   "
							+ claim1.getClaimType() + "    "
							+ claim1.getPolicyNumber());
				}
				
				boolean detailChoiceDoFlag=false;
				do {
					try {
						scanner=new Scanner(System.in);
				System.out
						.println("If you want to view the detailed view of the claim press 1");
				int viewDetailChoice = scanner.nextInt();
				switch (viewDetailChoice) {
				case 1:
				boolean policyFlag=false;
				
					do {
					System.out.println("Enter the policy number:");
					Long policyNumber = scanner.nextLong();
					CommomMethods commonMethod= new CommonMethodsImpl();
					boolean validatePolicyNumberFlag = commonMethod
							.validatePolicyNumber(policyNumber);
					if(validatePolicyNumberFlag) {
						policyFlag=true;
					List<PolicyDetails> policyDetailsList = new ArrayList<>();
					policyDetailsList = service
							.reportGeneration(policyNumber);
					for (PolicyDetails out : policyDetailsList) {

						System.out.println(out.getClaimReason() + "   "
								+ out.getAccidentLocationStreet()
								+ "   " + out.getAccidentCity() + "   "
								+ out.getAccidentState() + "   "
								+ out.getAccidentZip());
						break;
					}
					for (PolicyDetails out : policyDetailsList) {
						System.out.println(out.getClaimQuesDesc()
								+ "   " + out.getAnswer());
					}
					detailChoiceDoFlag=true;
					}else
					{
						policyFlag=false;
						System.out.println("please enter only in 10 digits");
					}
					}while(!policyFlag);
					
					break;

				default:
					detailChoiceDoFlag=false;
					System.err.println("please only press one if you want the detailed view");
					break;
				}
					}catch(InputMismatchException e) {
						
						detailChoiceDoFlag=false;
						System.err.println("please enter only in digits");
						
					}
				

				}while(!detailChoiceDoFlag);
			} catch (ICSException e) {
				System.err.println("Connection Error.");
			}

			
			break;
		default:
			break;
		}
		

		
	}
	
	

}
