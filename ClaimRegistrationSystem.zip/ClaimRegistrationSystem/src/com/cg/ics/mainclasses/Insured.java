package com.cg.ics.mainclasses;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.Policy;
import com.cg.ics.service.CommomMethods;
import com.cg.ics.service.ICSService;
import com.cg.ics.service.implementation.CommonMethodsImpl;
import com.cg.ics.service.implementation.ICSServiceImpl;
import com.cg.ics.ui.ClaimInformation;

public class Insured {

	public static void insured(String userName) {
		ICSService service = new ICSServiceImpl();
		Scanner scanner= new Scanner(System.in);
		CommomMethods commonMethods= new CommonMethodsImpl();
		
		List<Policy> list = new ArrayList<Policy>();
		System.out.println("-------------------------------USER PORTAL--------------------------------");
		System.out.println("\t\t\tWelcome "+userName+"\n");
		System.out.println("All your Policies are mentioned below:");
		try {
			list = service.getPolicyList(userName);
			if (list.size() > 0) {
				System.out.println("Policy Number " + "\t\t Policy Premium " + "   \t\t  Bussiness Segment ");
				for (Policy policy : list) {
					System.out.println(policy.getPolicyNumber() + " \t \t " + policy.getPolicyPremium() + "\t\t\t\t  " + policy.getBusinessSegment().getBusSegName());
				}
				System.out.println("\nPlease choose the desired option.");
				boolean userFlag=false;
				do {

					System.out.println("1.Create Claim\t\t2.View Status Of Claim");
					System.out.println("\nEnter your choice:");
					try {
						scanner= new Scanner(System.in);
						
						Integer choice1 = scanner.nextInt();
						userFlag=true;
						switch (choice1) {
						case 1:
							Claim claim = null;
							claim = ClaimInformation.getClaimInformation();
							if (claim == null) {
								scanner.close();
								return;
							}else {
								try {
									Long claimNumber = commonMethods.generateClaim(claim);
									System.out.println("You request for claim has been successfully generated");
									System.out.println("Your Claim Id: "+ claimNumber);
									System.out.println("Please Store your claimID for viewing status of claim. Thank You!!");
								} catch (ICSException e) {
									System.err.println("Cannot create Claim... Try again after some time...");
								}
							}
							break;
						case 2:

							List<Claim> claimList = new ArrayList<Claim>();
							claimList = commonMethods.viewClaim(userName);
							if (claimList.size() > 0) {
								System.out.println("Claimnumber  "
										+ "ClaimReason  " + "AccidentStreet  "
										+ "AccidentCity  " + "AccidentState  "
										+ "AccidentZip  " + "PolicyNumber  ");
								for (Claim claim2 : claimList) {
									System.out.println(claim2.getClaimNumber()
											+ "  " + claim2.getClaimReason() + "  "
											+ claim2.getAccidentLocationStreet()
											+ "  " + claim2.getAccidentCity()
											+ "  " + claim2.getAccidentState()
											+ "  " + claim2.getAccidentZip() + "  "
											+ claim2.getPolicyNumber() + "  "
											+ claim2.getClaimType());

								}
							} else {
								System.out.println("You don't have any Policies. Thank You.!!!");
							}

							break;

						default:
							System.err.println("\n\nINVALID CHOICE. TRY AGAIN...");
							userFlag=false;
							break;
						}
					} catch (InputMismatchException e) {
						System.err.println("\n\nChoice should contain only INTEGER(1 or 2) values. Please try again...");
					}
					
				} while (!userFlag);
				

				
			} else {
				System.out.println("You Have No Policies to Claim. Create Policy to Claim...");
			}
			
		} catch (ICSException e1) {
			System.err.println("Connection Error");
		}

		
		
		
	}
	

}
