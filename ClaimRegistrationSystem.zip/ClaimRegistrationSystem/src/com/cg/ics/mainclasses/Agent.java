package com.cg.ics.mainclasses;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.Policy;
import com.cg.ics.service.CommomMethods;
import com.cg.ics.service.ICSService;
import com.cg.ics.service.implementation.CommonMethodsImpl;
import com.cg.ics.service.implementation.ICSServiceImpl;
import com.cg.ics.ui.ClaimInformation;

public class Agent {

	public static void agent(String userName) {
		
		System.err.println(userName);
		
		
		Scanner scanner= new Scanner(System.in);
		ICSService service= new ICSServiceImpl();
		CommomMethods commonMethods= new CommonMethodsImpl();
		
		List<Policy> list = new ArrayList<Policy>();
		System.out.println("-------------------------------AGENT PORTAL---------------------------------");
		System.out.println("\t\t\tWelcome "+userName+"\n");
		System.out.println("All your Policies are mentioned below:");
		
		try {
			list = service.getPolicyList(userName);
		} catch (ICSException e1) {
			System.out.println("Connection Error");
		}
		if (list.size() > 0) {
			System.out.println("Policy Number " + "\t\t Policy Premium " + "   \t\t  Bussiness Segment ");
			for (Policy policy : list) {
				System.out.println(policy.getPolicyNumber() + " \t \t " + policy.getPolicyPremium() + "\t\t\t\t  " + policy.getBusinessSegment().getBusSegName());
			}
		}
		
		
		
		
		boolean agentChoiceFlag = false;
		Claim claim = null;
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tWelcome "+userName+"\n");
		do {
			System.out.println("1.Create Claim\t\t2.View Status Of Claim");
			System.out.println("\nEnter your choice:");

			try {
				scanner = new Scanner(System.in);
				Integer agentChoice = scanner.nextInt();

				switch (agentChoice) {

				case 1:
					service = new ICSServiceImpl();
					claim = ClaimInformation.getClaimInformation();
					if (claim == null) {
						scanner.close();
						return;
					}
					try {
						Long claimNumber = commonMethods.generateClaim(claim);
						System.out.println("You request for claim has been successfully generated");
						System.out.println("Your Claim Id: "+ claimNumber);
						System.out.println("Please Store your claimID for viewing status of claim. Thank You!!");
					} catch (ICSException e) {
						System.err.println("Cannot create Claim... Try again after some time...");
					}

					agentChoiceFlag = true;
					break;
				case 2:
					service= new ICSServiceImpl();

					System.out
							.println("**********View Details Options**********");
					System.out.println("1.View All claim details");
					System.out.println("2.View claim details based on policy number");
					System.out.println("choose the ViewDetails option");
					int ViewDetailsChoice = scanner.nextInt();
					switch (ViewDetailsChoice) {
					case 1:
						List<Claim> claimList = new ArrayList<Claim>();
						try {
							claimList = commonMethods.viewClaim(userName);
							if (claimList.size() > 0) {
								System.out.println(" claimnumber "+ " ClaimReason "+ " AccidentStreet "+ " AccidentCity "+ " AccidentState "+ " AccidentZip "+ " PolicyNumber ");
								for (Claim claim2 : claimList) {
									System.out.println(claim2.getClaimNumber()+ "  "+ claim2.getClaimReason()+ "  "+ claim2.getAccidentLocationStreet()+ "  "+ claim2.getAccidentCity()+ "  "+ claim2.getAccidentState()+ "  "+ claim2.getAccidentZip()+ "  "+ claim2.getPolicyNumber()+ "  "+ claim2.getClaimType());
								}
							} else {
								System.out.println("no records");
							}
						} catch (ICSException e) {
							System.err.println("Connection Error");
						}
						break;
					case 2:
						List<Claim> list2 = new ArrayList<>();
						System.out.println("Enter the policy number to search");
						Long PolicyNumberToviewClaimDetails = scanner.nextLong();
						try {
							list2 = service.viewClaimDetailsBasedOnPolicyNumber(PolicyNumberToviewClaimDetails);
							if (!(list2.isEmpty())) {
								System.out.println("policyNumber" + " "
										+ " claimNumber" + " "
										+ "claimType");
								for (Claim claim2 : list2) {
									System.out.println(claim2
											.getPolicyNumber()
											+ " "
											+ claim2.getClaimNumber()
											+ " "
											+ claim2.getClaimType());
								}
							} else {
								System.err.println("You haven't Claimed any such policy");
							}
						} catch (ICSException e) {
							System.err.println("Connection Error");
						}
						

						break;
					default:
						System.err.println("please enter valid choice:");
						break;

					}
					agentChoiceFlag = true;
					break;

				default:
					System.err.println("Invalid Choice Entered. Please try Again...");
					agentChoiceFlag = false;
					break;
				}

			} catch (InputMismatchException e) {
				System.err.println("Choice should contain only INTEGER values. Please try again...");
				agentChoiceFlag = false;
			}

		} while (!agentChoiceFlag);

		

		
	}
	
}
