package com.cg.ics.model;

public class ClaimQuestions {

	private String claimQuesId;
	private Integer claimQuesSeq;
	private String busSegId;
	private String claimQuesDesc;
	private String claimQuesAns1;
	private Long claimQuesAns1Weightage;
	private String claimQuesAns2;
	private Long claimQuesAns2Weightage;
	private String claimQuesAns3;
	private Long claimQuesAns3Weightage;
	private String claimQuesAns4;
	private Long claimQuesAns4Weightage;
	
	public ClaimQuestions() {
		// TODO Auto-generated constructor stub
	}

	public ClaimQuestions(String claimQuesId, Integer claimQuesSeq, String busSegId, String claimQuesDesc,
			String claimQuesAns1, Long claimQuesAns1Weightage, String claimQuesAns2, Long claimQuesAns2Weightage,
			String claimQuesAns3, Long claimQuesAns3Weightage, String claimQuesAns4, Long claimQuesAns4Weightage) {
		super();
		this.claimQuesId = claimQuesId;
		this.claimQuesSeq = claimQuesSeq;
		this.busSegId = busSegId;
		this.claimQuesDesc = claimQuesDesc;
		this.claimQuesAns1 = claimQuesAns1;
		this.claimQuesAns1Weightage = claimQuesAns1Weightage;
		this.claimQuesAns2 = claimQuesAns2;
		this.claimQuesAns2Weightage = claimQuesAns2Weightage;
		this.claimQuesAns3 = claimQuesAns3;
		this.claimQuesAns3Weightage = claimQuesAns3Weightage;
		this.claimQuesAns4 = claimQuesAns4;
		this.claimQuesAns4Weightage = claimQuesAns4Weightage;
	}

	public String getClaimQuesId() {
		return claimQuesId;
	}

	public void setClaimQuesId(String claimQuesId) {
		this.claimQuesId = claimQuesId;
	}

	public Integer getClaimQuesSeq() {
		return claimQuesSeq;
	}

	public void setClaimQuesSeq(Integer claimQuesSeq) {
		this.claimQuesSeq = claimQuesSeq;
	}

	public String getBusSegId() {
		return busSegId;
	}

	public void setBusSegId(String busSegId) {
		this.busSegId = busSegId;
	}

	public String getClaimQuesDesc() {
		return claimQuesDesc;
	}

	public void setClaimQuesDesc(String claimQuesDesc) {
		this.claimQuesDesc = claimQuesDesc;
	}

	public String getClaimQuesAns1() {
		return claimQuesAns1;
	}

	public void setClaimQuesAns1(String claimQuesAns1) {
		this.claimQuesAns1 = claimQuesAns1;
	}

	public Long getClaimQuesAns1Weightage() {
		return claimQuesAns1Weightage;
	}

	public void setClaimQuesAns1Weightage(Long claimQuesAns1Weightage) {
		this.claimQuesAns1Weightage = claimQuesAns1Weightage;
	}

	public String getClaimQuesAns2() {
		return claimQuesAns2;
	}

	public void setClaimQuesAns2(String claimQuesAns2) {
		this.claimQuesAns2 = claimQuesAns2;
	}

	public Long getClaimQuesAns2Weightage() {
		return claimQuesAns2Weightage;
	}

	public void setClaimQuesAns2Weightage(Long claimQuesAns2Weightage) {
		this.claimQuesAns2Weightage = claimQuesAns2Weightage;
	}

	public String getClaimQuesAns3() {
		return claimQuesAns3;
	}

	public void setClaimQuesAns3(String claimQuesAns3) {
		this.claimQuesAns3 = claimQuesAns3;
	}

	public Long getClaimQuesAns3Weightage() {
		return claimQuesAns3Weightage;
	}

	public void setClaimQuesAns3Weightage(Long claimQuesAns3Weightage) {
		this.claimQuesAns3Weightage = claimQuesAns3Weightage;
	}

	public String getClaimQuesAns4() {
		return claimQuesAns4;
	}

	public void setClaimQuesAns4(String claimQuesAns4) {
		this.claimQuesAns4 = claimQuesAns4;
	}

	public Long getClaimQuesAns4Weightage() {
		return claimQuesAns4Weightage;
	}

	public void setClaimQuesAns4Weightage(Long claimQuesAns4Weightage) {
		this.claimQuesAns4Weightage = claimQuesAns4Weightage;
	}

	@Override
	public String toString() {
		return "ClaimQuestions [claimQuesId=" + claimQuesId + ", claimQuesSeq=" + claimQuesSeq + ", busSegId="
				+ busSegId + ", claimQuesDesc=" + claimQuesDesc + ", claimQuesAns1=" + claimQuesAns1
				+ ", claimQuesAns1Weightage=" + claimQuesAns1Weightage + ", claimQuesAns2=" + claimQuesAns2
				+ ", claimQuesAns2Weightage=" + claimQuesAns2Weightage + ", claimQuesAns3=" + claimQuesAns3
				+ ", claimQuesAns3Weightage=" + claimQuesAns3Weightage + ", claimQuesAns4=" + claimQuesAns4
				+ ", claimQuesAns4Weightage=" + claimQuesAns4Weightage + "]";
	}
	
	
	
}
