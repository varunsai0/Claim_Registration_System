package com.cg.ics.queries;

public interface QueryMapper {
	
	String getLoginDetails="select * from user_role";
	
	String insertIntoUsers="insert into user_role values(?,?,?)";
	
	String getAllClaims="select * from claim";
	
	String getDetailedView="select c.claim_number,c.claim_reason,c.accident_street,c.accident_CITY,c.accident_state,c.accident_zip,"
			+ "c.claim_type,c.policy_number,p.question_id,p.answer,q.claim_ques_desc from claim c,policy_details p,claim_questions q "
			+ "where (c.policy_number=p.policy_number and p.question_id=q.claim_ques_id and c.policy_number=?)";
	//===============================================
	String getPolicyList = "select p.policy_number,p.policy_premium,a.account_number,b.bus_SEG_name from accounts a,user_role u,policy p,business_segment b where a.username=u.username and b.bus_seg_id=p.bus_seg_id and a.account_number=p.account_number and u.username=?";

	String claimCreation = "insert into claim values(claim_seq.nextval,?,?,?,?,?,?,?)";
	
	String viewClaim = " select c.claim_number,c.claim_reason,c.accident_street,c.accident_city,c.accident_state,c.accident_zip,c.claim_type,c.policy_number from claim c,policy p,accounts a,user_role u where u.username=a.username and a.account_number=p.account_number and p.policy_number=c.policy_number and u.username=?";
	
	String claimQuestions ="select * from claim_questions where bus_seg_id=(select bus_seg_id from policy where policy_number = ?)";
	
	String insertIntoPolicyDetails="insert into policy_details values(?,?,?)";
	//=========================================
	

	String validatePolicyNumberQuery = "select policy_number from policy";
	String addGenerateClaimQuery = "insert into claim values(generate_Claim_Id.nextval,?, ?, ?, ?, ?, ?, ?)";
	String getClaimNumberOrCheckWhetherClaimedQuery = "select CLAIM_NUMBER from claim where POLICY_NUMBER=?";
	
	//===================================================================
	
String viewClaimDetails= "SELECT * FROM claim";
	
	String viewClaimDetailsBasedOnPolicyNumber="SELECT * FROM claim WHERE policy_Number=?";

	String getAllPolicyListQuery = "select p.policy_number,p.policy_premium,a.account_number,b.bus_SEG_name from accounts a,user_role u,policy p,business_segment b where a.username=u.username and b.bus_seg_id=p.bus_seg_id and a.account_number=p.account_number";

}
