package com.cg.ics.dao.implementation.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ics.dao.UnderWriterMethods;
import com.cg.ics.dao.implementation.UnderWriterMethodsImpl;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.Policy;
import com.cg.ics.model.PolicyDetails;

public class UnderWriterMethodsImplTest {
	UnderWriterMethods underWriter=null;
	@Before
	public void setUp() throws Exception {
		underWriter= new UnderWriterMethodsImpl();
	}

	@After
	public void tearDown() throws Exception {
		underWriter=null;
	}

	@Test
	public void testGetAllPolicyList() {
		List<Policy> list = new ArrayList<Policy>();
		int flag=0;
	try {
		list=underWriter.getAllPolicyList();
		if(list.size()>0){
			flag=1;
		}
		else{
			flag=0;
		}
		assertEquals(1, flag);
		
	} catch (ICSException e) {
		System.err.println("Connection Error");
	}
	}

	@Test
	public void testViewClaimDetails() {
		List<Claim> list = new ArrayList<>();
		int flag=0;
		try {
			list=underWriter.getAllClaims();
			if(list.size()>0){
				flag=1;
			}
			assertEquals(1, flag);
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}
	}

	@Test
	public void testGetAllClaims() {
		List<Claim> list = new ArrayList<>();
		int flag=0;
		try {
			list=underWriter.getAllClaims();
			if(list.size()>0){
				flag=1;
			}
			assertEquals(1, flag);
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}
	}

	@Test
	public void testReportGeneration() {
		List<PolicyDetails> list = new ArrayList<>();
		int flag=0;
		try {
			list=underWriter.reportGeneration(8100001001l);
			
			if(list.size()>0){
				flag=1;
			}
			assertEquals(1, flag);
			
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}
	}

}
