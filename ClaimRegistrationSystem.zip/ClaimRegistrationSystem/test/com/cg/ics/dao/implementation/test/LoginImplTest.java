package com.cg.ics.dao.implementation.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ics.dao.Login;
import com.cg.ics.dao.implementation.LoginImpl;
import com.cg.ics.exceptions.ICSException;

public class LoginImplTest {
Login login=null;

	@Before
	public void setUp() throws Exception {
		login=new LoginImpl();
	}

	@After
	public void tearDown() throws Exception {
		 login=null;
	}

	@Test
	public void testUserLogin() {
		try {
			boolean flag=login.userLogin("User1", "user1");
			boolean flag1=true;
			assertEquals(flag1, flag);

		} catch (ICSException e) {
			System.err.println("Connection Error");
		}
	}

	

}
