package com.cg.ics.dao.implementation.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ics.dao.CommonMethods;
import com.cg.ics.dao.implementation.CommonMethodsImplementation;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;
import com.cg.ics.model.ClaimQuestions;
import com.cg.ics.model.PolicyDetails;

public class CommonMethodsImplementationTest {
	CommonMethods commonMethodsDao=null;
	@Before
	public void setUp() throws Exception {
		commonMethodsDao= new CommonMethodsImplementation();
	}

	@After
	public void tearDown() throws Exception {
		commonMethodsDao=null;
	}
	

	@Test
	public void testClaimQuestions() {
		List<ClaimQuestions> list = new ArrayList<ClaimQuestions>();
		try {
			list=commonMethodsDao.claimQuestions(8100001014L);
			int flag=0;
			if (list.size() > 0) {
				flag = 1;
			} else {
				flag = 0;
			}
			assertEquals(1, flag);
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}
	}

	@Test
	public void testInsertIntoPolicyDetails() {
		PolicyDetails details=new PolicyDetails();
		details.setPolicyNumber(8100001005l);
		details.setQuestionId("3004");
		details.setAnswer("75%");
		int result=0;
		try {
			result=commonMethodsDao.insertIntoPolicyDetails(details);
			assertEquals(1, result);
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}
	}

	@Test
	public void testValidatePolicyNumber() {
		try {
			boolean flag=commonMethodsDao.validatePolicyNumber(8100001014L);
			boolean flag1=true;
			assertEquals(flag1, flag);
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}
	}

	@Test
	public void testCheckWhetherClaimed() {
		try {
			boolean flag=commonMethodsDao.checkWhetherClaimed(8100001014L);
			boolean flag1=true;
			assertEquals(flag1, flag);
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}
	}


	@Test
	public void testViewClaim() {
		List<Claim> list = new ArrayList<Claim>();
		try {
			list=commonMethodsDao.viewClaim("User1");
			int flag;
			if (list.size() > 0) {
				flag = 1;
			} else {
				flag = 0;
			}
			assertEquals(1, flag);
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}
	}

}
