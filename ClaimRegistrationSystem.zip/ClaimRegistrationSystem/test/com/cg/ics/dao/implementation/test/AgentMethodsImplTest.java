package com.cg.ics.dao.implementation.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ics.dao.AgentMethods;
import com.cg.ics.dao.implementation.AgentMethodsImpl;
import com.cg.ics.exceptions.ICSException;
import com.cg.ics.model.Claim;

public class AgentMethodsImplTest {
	AgentMethods agent = null;

	@Before
	public void setUp() throws Exception {
		agent = new AgentMethodsImpl();
	}

	@After
	public void tearDown() throws Exception {
		agent = null;
	}

	@Test
	public void testViewClaimDetailsBasedOnPolicyNumber() {
		List<Claim> list = new ArrayList<>();
		int flag = 0;
		try {
			list = agent.viewClaimDetailsBasedOnPolicyNumber(8100001014l);
			if (list.size() > 0) {
				flag = 1;
			} else {
				flag = 0;
			}
		assertEquals(1, flag);
			
		} catch (ICSException e) {
			System.err.println("Connection Error");
		}

	}

}
